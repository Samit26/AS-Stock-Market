import Companies from "./Companies";

function CompaniesHolder() {
  return (
    <div className="companiesHolder">
      <Companies />
    </div>
  );
}

export default CompaniesHolder;
