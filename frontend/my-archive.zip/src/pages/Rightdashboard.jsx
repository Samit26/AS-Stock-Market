import "./rightdashboard.css";
import CompaniesHolder from "../components/CompaniesHolder";

const Rightdashboard = () => {
  return (
    <>
      <CompaniesHolder />
    </>
  );
};

export default Rightdashboard;
