const AboutUs = () => {
  return <>Hii</>;
};

export default AboutUs;
